* This lab to test our understanding of form data and loops.

* *Date Created*: October 19 2022
* *Last Modification Date*: October 20 2022
* *Lab URL*: <https://web.cs.dal.ca/~ofume/csci3172/lab5/>
* *Git URL*: <https://git.cs.dal.ca/ofume/b00738568_web_centric_computing_csci3172.git>

## Authors
* [Lynda Ofume](Ly863136@dal.ca) - *Developer/Designer*

## Getting Started

- To view the assignment please refer to the Lab URL in order to view code.
- In order to view source code, please view the Git URL to view.

## Sources Used

#3 Lab 1, CSS styling (modified), accessed October 20, 2022

## Acknowledgments

* Basic styling modifications, Lab 1, CSS styling, accessed October 20, 2022
