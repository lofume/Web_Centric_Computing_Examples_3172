<!--- The following README.md sample file was adapted from https://gist.github.com/PurpleBooth/109311bb0361f32d87a2#file-readme-template-md by Gabriella Mosquera for academic use ---> 
<!--- You may delete any comments in this sample README.md file. If needing to use as a .txt file then simply delete all comments, edit as needed, and save as a README.txt file --->

# Lab 10

* To learn how to use REST API with get operation 

* *Date Created*: November 29 2022
* *Last Modification Date*: November 29 2022

* *Lab URL*: <http://localhost:80/csci3172-lab10>
* *GitLab URL: <https://git.cs.dal.ca/ofume/b00738568_web_centric_computing_csci3172.git>

## Authors
* [Lynda Ofume](Ly863136@dal.ca) - *Developer/Designer*


## Getting Started

- To view the result please click run on js program for node.js and then open the website in your browser.
- You can view source code at the given GitLab URL


## Sources Used
1. Used start code created by Hemanth that was posted on brightspace to implement features, Accessed November 29, 2022



## Acknowledgments
- Hemanth Nadipineni, Starter code, Accessed November 29, 2022
