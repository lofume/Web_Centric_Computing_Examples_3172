function showForm(){
    
    document.getElementById('form1').innerHTML= document.fillForm.fname.value;
    document.getElementById('form2').innerHTML= document.fillForm.lname.value;
    document.getElementById('form3').innerHTML= document.fillForm.gender.value;
    document.getElementById('form4').innerHTML= document.fillForm.country.value;
}